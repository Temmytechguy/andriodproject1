package com.doranco.tpcontext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button buttonContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonContact = findViewById(R.id.buttonContact);

        buttonContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getContacts();

            }
        });
    }

    public void getContacts()
    {
        //verification de la permission
        boolean permission = ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED;

        //demande de permission
        if(permission)
        {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    0);
        }
        else{
            //permission autorisee
            ContentResolver contentResolver = getContentResolver();

            Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;

            Cursor cursor = contentResolver.query(uri,
                    null,null,null, null);

            int nombreContacts = cursor.getCount();

            Toast.makeText(this,"Nombre de contacts : " + nombreContacts, Toast.LENGTH_SHORT).show();

            int indexNom =  cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            int indexNumero = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

            cursor.moveToFirst();

            while(!cursor.isAfterLast())
            {
                Log.e("Voir contacts","{Nom : " + cursor.getString(indexNom) +
                        ", Telephone : " + cursor.getString(indexNumero) + "}");
                cursor.moveToNext();

            }
            cursor.close();

        }

    }
}